from flask_restful import  Api
from flask_pymysql import MySQL

api = Api()
db=MySQL()